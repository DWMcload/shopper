SELECT * FROM migrations;SELECT * FROM cache;
